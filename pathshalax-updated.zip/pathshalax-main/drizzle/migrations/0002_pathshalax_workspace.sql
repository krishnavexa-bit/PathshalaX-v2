-- Extended student profile preferences, stored with the existing per-student settings row.
ALTER TABLE public.student_settings
  ADD COLUMN IF NOT EXISTS date_of_birth date,
  ADD COLUMN IF NOT EXISTS board text NOT NULL DEFAULT 'CBSE',
  ADD COLUMN IF NOT EXISTS stream text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS study_hours numeric(3,1) NOT NULL DEFAULT 2,
  ADD COLUMN IF NOT EXISTS academic_goal text NOT NULL DEFAULT 'Build a consistent study routine',
  ADD COLUMN IF NOT EXISTS strong_subjects text[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS difficult_subjects text[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS concentration_minutes integer NOT NULL DEFAULT 25,
  ADD COLUMN IF NOT EXISTS navigation_position text NOT NULL DEFAULT 'bottom',
  ADD COLUMN IF NOT EXISTS accent_color text NOT NULL DEFAULT '#ffb703',
  ADD COLUMN IF NOT EXISTS profile_photo text;

ALTER TABLE public.student_settings DROP CONSTRAINT IF EXISTS student_settings_study_hours_check;
ALTER TABLE public.student_settings ADD CONSTRAINT student_settings_study_hours_check CHECK (study_hours >= 0.5 AND study_hours <= 12);
ALTER TABLE public.student_settings DROP CONSTRAINT IF EXISTS student_settings_concentration_check;
ALTER TABLE public.student_settings ADD CONSTRAINT student_settings_concentration_check CHECK (concentration_minutes IN (15, 25, 35, 45, 60));
ALTER TABLE public.student_settings DROP CONSTRAINT IF EXISTS student_settings_navigation_position_check;
ALTER TABLE public.student_settings ADD CONSTRAINT student_settings_navigation_position_check CHECK (navigation_position IN ('bottom', 'top'));

-- Private student archive and profile-photo storage. Objects are accessible only within
-- the first path segment, which must be the authenticated user's UUID.
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'student-archive',
  'student-archive',
  false,
  20971520,
  ARRAY[
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'image/png', 'image/jpeg', 'image/webp', 'image/gif', 'text/plain'
  ]
)
ON CONFLICT (id) DO UPDATE SET
  public = false,
  file_size_limit = EXCLUDED.file_size_limit,
  allowed_mime_types = EXCLUDED.allowed_mime_types;

DROP POLICY IF EXISTS "Students read own PathshalaX files" ON storage.objects;
CREATE POLICY "Students read own PathshalaX files"
  ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'student-archive' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "Students upload own PathshalaX files" ON storage.objects;
CREATE POLICY "Students upload own PathshalaX files"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'student-archive' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "Students update own PathshalaX files" ON storage.objects;
CREATE POLICY "Students update own PathshalaX files"
  ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'student-archive' AND (storage.foldername(name))[1] = auth.uid()::text)
  WITH CHECK (bucket_id = 'student-archive' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "Students delete own PathshalaX files" ON storage.objects;
CREATE POLICY "Students delete own PathshalaX files"
  ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'student-archive' AND (storage.foldername(name))[1] = auth.uid()::text);
