// @ts-nocheck -- workspace modules share the existing JSONB student progress contract.
import React, { useEffect, useMemo, useState } from 'react';
import Icon from './icons';
import { supabase } from '@/integrations/supabase/client';
import { subjectsFor } from './curriculum';
import { questions } from './data';

const BUCKET = 'student-archive';
const MAX_FILE_SIZE = 20 * 1024 * 1024;
const ALLOWED_EXTENSIONS = new Set(['pdf', 'doc', 'docx', 'ppt', 'pptx', 'png', 'jpg', 'jpeg', 'webp', 'gif', 'txt']);

const dateKey = (date = new Date()) => {
  const d = new Date(date);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
};
const weekKey = (date = new Date()) => {
  const d = new Date(date);
  const day = (d.getDay() + 6) % 7;
  d.setDate(d.getDate() - day);
  return dateKey(d);
};
const uid = () => globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
const safeText = (value, max = 180) => String(value || '').trim().slice(0, max);
const toDate = (value) => new Date(`${value}T00:00:00`);
const prettyDate = (value) => value ? toDate(value).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : '—';
const emptyProgress = { calendarItems: [], trackerRecords: [], doubtDetails: {}, notes: [], studySessions: [], archiveFiles: [], archiveFolders: ['My Materials'], testResults: [], rewardEvents: [], weeklyXp: {}, lifetimePoints: 0 };

function awardOnce(previous, eventKey, points) {
  const events = Array.isArray(previous.rewardEvents) ? previous.rewardEvents : [];
  if (events.includes(eventKey)) return {};
  const today = dateKey();
  const week = weekKey();
  const before = (previous.weeklyXp || {})[week] || 0;
  const after = before + points;
  const leagueFor = (value) => value >= 1500 ? 'Champion' : value >= 900 ? 'Diamond' : value >= 500 ? 'Gold' : value >= 200 ? 'Silver' : 'Bronze';
  const oldLeague = leagueFor(before);
  const newLeague = leagueFor(after);
  const rank = { Bronze: 0, Silver: 1, Gold: 2, Diamond: 3, Champion: 4 };
  const transition = oldLeague !== newLeague ? { week, league: newLeague, achievedAt: Date.now() } : null;
  const highest = previous.highestLeague || 'Bronze';
  return {
    xp: (previous.xp || 0) + points,
    lifetimePoints: (previous.lifetimePoints || previous.xp || 0) + points,
    dailyXp: { ...(previous.dailyXp || {}), [today]: ((previous.dailyXp || {})[today] || 0) + points },
    weeklyXp: { ...(previous.weeklyXp || {}), [week]: after },
    rewardEvents: [...events, eventKey],
    leagueHistory: transition ? [...(previous.leagueHistory || []), transition] : (previous.leagueHistory || []),
    highestLeague: rank[newLeague] > rank[highest] ? newLeague : highest,
    leagueAchievements: transition ? { ...(previous.leagueAchievements || {}), [newLeague]: ((previous.leagueAchievements || {})[newLeague] || 0) + 1 } : (previous.leagueAchievements || {}),
  };
}

function Field({ label, children }) {
  return <label className="px-field"><span>{label}</span>{children}</label>;
}
function Empty({ title, detail, action }) {
  return <section className="panel px-empty"><div className="empty-art"><Icon name="sparkle" size={34} /></div><h2>{title}</h2><p className="muted">{detail}</p>{action}</section>;
}
function ModuleHead({ title, description, action }) {
  return <header className="page-head"><div><h1>{title}</h1><p>{description}</p></div>{action}</header>;
}

export default function ProductivityHub({ page, progress, setProgress, settings, userId, onEditSettings, onNavigate }) {
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const [search, setSearch] = useState('');
  const [now, setNow] = useState(Date.now());
  const subjects = useMemo(() => subjectsFor(settings.classLevel).filter((s) => settings.subjects.includes(s.name)), [settings.classLevel, settings.subjects]);
  const allChapters = useMemo(() => subjects.flatMap((s) => s.chapters.map((c) => ({ ...c, subject: s.name }))), [subjects]);
  const state = { ...emptyProgress, ...progress };
  const update = (mutator) => setProgress((prev) => {
    const next = typeof mutator === 'function' ? mutator(prev) : mutator;
    return { ...prev, ...next };
  });
  const showMessage = (text) => { setMessage(text); window.setTimeout(() => setMessage(''), 3500); };
  const currentWeekPoints = state.weeklyXp?.[weekKey()] || 0;
  const league = currentWeekPoints >= 1500 ? 'Champion' : currentWeekPoints >= 900 ? 'Diamond' : currentWeekPoints >= 500 ? 'Gold' : currentWeekPoints >= 200 ? 'Silver' : 'Bronze';
  const leagueCount = Math.max(1, currentWeekPoints >= 1500 ? Math.floor(currentWeekPoints / 1500) : currentWeekPoints >= 900 ? 4 : currentWeekPoints >= 500 ? 3 : currentWeekPoints >= 200 ? 2 : 1);

  if (page === 'Calendar') {
    return <CalendarModule {...{ state, update, subjects, allChapters, settings, showMessage, currentWeekPoints, league }} />;
  }
  if (page === 'Tracker') {
    return <TrackerModule {...{ state, update, subjects, allChapters, showMessage }} />;
  }
  if (page === 'Doubts') {
    return <DoubtsModule {...{ state, update, showMessage, onNavigate }} />;
  }
  if (page === 'Archive') {
    return <ArchiveModule {...{ state, update, userId, search, setSearch, busy, setBusy, showMessage }} />;
  }
  if (page === 'Tests') {
    return <TestsModule {...{ state, update, subjects, settings, showMessage, onNavigate }} />;
  }
  if (page === 'Notes') {
    return <NotesModule {...{ state, update, subjects, allChapters, search, setSearch, showMessage }} />;
  }
  if (page === 'Timer') {
    return <TimerModule {...{ state, update, subjects, allChapters, now, setNow, showMessage }} />;
  }
  if (page === 'Settings') {
    return <SettingsModule {...{ settings, state, onEditSettings, showMessage }} />;
  }
  return null;
}

function CalendarModule({ state, update, subjects, allChapters, settings, showMessage, currentWeekPoints, league }) {
  const [selectedDate, setSelectedDate] = useState(dateKey());
  const [form, setForm] = useState({ title: '', type: 'Homework', date: dateKey(), time: '', priority: 'Medium', repeat: 'Never', reminder: 'None', subject: '', chapter: '' });
  const [showForm, setShowForm] = useState(false);
  const [month, setMonth] = useState(dateKey().slice(0, 7));
  const [planner, setPlanner] = useState([]);
  const [planHours, setPlanHours] = useState(settings.studyHours || 2);

  useEffect(() => {
    const checkReminders = () => {
      if (!('Notification' in window) || Notification.permission !== 'granted') return;
      const today = dateKey();
      const now = new Date();
      state.calendarItems.forEach((item) => {
        if (!item.reminder || item.reminder === 'None' || item.completed) return;
        let occurrenceDate = item.date;
        if (item.repeat === 'Daily') occurrenceDate = today;
        if (item.repeat === 'Weekly') {
          const base = toDate(item.date);
          const next = new Date(now.getFullYear(), now.getMonth(), now.getDate());
          const daysAhead = (base.getDay() - next.getDay() + 7) % 7;
          next.setDate(next.getDate() + daysAhead);
          occurrenceDate = dateKey(next);
          if (occurrenceDate < item.date) return;
        }
        if (item.repeat !== 'Daily' && item.repeat !== 'Weekly' && item.date < today) return;
        if (item.repeat !== 'Daily' && item.repeat !== 'Weekly' && item.date !== today && item.reminder !== '1 day before') return;
        if ((item.remindedDates || []).includes(occurrenceDate)) return;
        if (item.repeat !== 'Never' && (item.completedDates || []).includes(occurrenceDate)) return;
        const dueAt = new Date(`${occurrenceDate}T${item.time || '09:00'}:00`).getTime();
        const offset = item.reminder === '10 minutes before' ? 10 * 60_000 : item.reminder === '1 day before' ? 24 * 60 * 60_000 : 0;
        const fireAt = dueAt - offset;
        if (now.getTime() >= fireAt && now.getTime() - fireAt < 60 * 60_000) {
          new Notification(`PathshalaX reminder: ${item.title}`, { body: `${item.type}${item.subject ? ` · ${item.subject}` : ''}` });
          update((prev) => ({ calendarItems: prev.calendarItems.map((entry) => entry.id === item.id ? { ...entry, remindedDates: [...(entry.remindedDates || []), occurrenceDate] } : entry) }));
        }
      });
    };
    checkReminders();
    const id = window.setInterval(checkReminders, 30_000);
    return () => window.clearInterval(id);
  }, [state.calendarItems]);

  const itemsForDate = state.calendarItems.filter((item) => {
    if (item.date === selectedDate) return true;
    if (!item.repeat || item.repeat === 'Never' || item.date > selectedDate) return false;
    if (item.repeat === 'Daily') return true;
    if (item.repeat === 'Weekly') return toDate(item.date).getDay() === toDate(selectedDate).getDay();
    return false;
  }).map((item) => ({ ...item, occurrenceDate: selectedDate, occurrenceCompleted: item.repeat === 'Never' ? Boolean(item.completed) : (item.completedDates || []).includes(selectedDate) }))
    .sort((a, b) => (a.time || '').localeCompare(b.time || ''));
  const upcomingExams = state.calendarItems.filter((item) => item.type === 'Examination' && item.date >= dateKey()).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 4);
  const monthDate = new Date(`${month}-01T00:00:00`);
  const days = new Date(monthDate.getFullYear(), monthDate.getMonth() + 1, 0).getDate();
  const firstDay = (monthDate.getDay() + 6) % 7;
  const dateCounts = new Set(state.calendarItems.map((x) => x.date));

  function addItem(event) {
    event.preventDefault();
    if (!safeText(form.title, 100) || !form.date) return showMessage('Add a title and date first.');
    const item = { ...form, title: safeText(form.title, 100), id: uid(), completed: false, createdAt: Date.now() };
    update((prev) => ({ calendarItems: [...(prev.calendarItems || []), item] }));
    setForm({ title: '', type: 'Homework', date: selectedDate, time: '', priority: 'Medium', repeat: 'Never', reminder: 'None', subject: '', chapter: '' });
    setShowForm(false);
    showMessage('Added to your calendar.');
  }
  function toggleItem(itemId, occurrenceDate) {
    update((prev) => ({ calendarItems: prev.calendarItems.map((item) => {
      if (item.id !== itemId) return item;
      if (!item.repeat || item.repeat === 'Never') return { ...item, completed: !item.completed };
      const dates = item.completedDates || [];
      return { ...item, completedDates: dates.includes(occurrenceDate) ? dates.filter((d) => d !== occurrenceDate) : [...dates, occurrenceDate] };
    }) }));
  }
  function removeItem(itemId) {
    update((prev) => ({ calendarItems: prev.calendarItems.filter((item) => item.id !== itemId) }));
  }
  function generatePlanner() {
    const subjectsByPriority = subjects.map((subject) => {
      const difficulty = (settings.difficultSubjects || []).includes(subject.name) ? 3 : 1;
      const strength = (settings.strongSubjects || []).includes(subject.name) ? -0.5 : 0;
      const unfinished = subject.chapters.filter((chapter) => !(state.completedChapters || []).includes(chapter.id)).length;
      const exam = upcomingExams.find((entry) => entry.subject === subject.name);
      const pending = state.calendarItems.filter((entry) => entry.subject === subject.name && !entry.completed && entry.date >= dateKey()).length;
      const daysAway = exam ? Math.max(1, Math.ceil((toDate(exam.date) - toDate(dateKey())) / 86400000)) : 999;
      return { subject, score: difficulty + strength + Math.min(3, unfinished / 4) + Math.min(2, pending * 0.5) + (exam ? Math.max(0, 4 - daysAway / 7) : 0), chapters: subject.chapters.filter((chapter) => !(state.completedChapters || []).includes(chapter.id)) };
    }).filter((x) => x.chapters.length).sort((a, b) => b.score - a.score);
    if (!subjectsByPriority.length) return showMessage('All selected chapters are complete. Add your next learning goals in Learn.');
    const blocks = [];
    const slots = Math.max(1, Math.min(12, Math.round(planHours * 2)));
    for (let day = 0; day < 7; day += 1) {
      const date = new Date(); date.setDate(date.getDate() + day);
      const dayKey = dateKey(date);
      for (let slot = 0; slot < slots; slot += 1) {
        const pick = subjectsByPriority[(day + slot) % subjectsByPriority.length];
        const chapter = pick.chapters[(day + slot) % pick.chapters.length];
        blocks.push({ id: uid(), title: `${pick.subject.name}: ${chapter.title}`, type: 'Study', date: dayKey, time: `${String(16 + Math.floor(slot / 2)).padStart(2, '0')}:${slot % 2 ? '30' : '00'}`, priority: pick.score > 4 ? 'High' : 'Medium', repeat: 'Never', subject: pick.subject.name, chapter: chapter.title, completed: false, generated: true });
      }
    }
    setPlanner(blocks);
    showMessage('A draft timetable is ready. Review it before adding it to your calendar.');
  }
  function applyPlanner() {
    update((prev) => ({ calendarItems: [...(prev.calendarItems || []), ...planner] }));
    setPlanner([]);
    showMessage('Your study timetable was added to the calendar.');
  }
  const monthLabel = monthDate.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });

  return <>
    <ModuleHead title="Calendar & task manager." description="Keep homework, exams, study sessions and personal deadlines in one place." action={<button className="btn btn-primary" onClick={() => setShowForm((v) => !v)}><Icon name="plus" size={17} />Add task</button>} />
    <div className="px-calendar-layout">
      <section className="panel px-calendar">
        <div className="panel-head"><h2>{monthLabel}</h2><div className="actions-row"><button className="chip-btn" onClick={() => setMonth((v) => { const d = new Date(`${v}-01T00:00:00`); d.setMonth(d.getMonth() - 1); return dateKey(d).slice(0, 7); })}>‹</button><button className="chip-btn" onClick={() => setMonth((v) => { const d = new Date(`${v}-01T00:00:00`); d.setMonth(d.getMonth() + 1); return dateKey(d).slice(0, 7); })}>›</button></div></div>
        <div className="px-calendar-grid">{['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((d) => <b key={d}>{d}</b>)}{Array.from({ length: firstDay }).map((_, i) => <span key={`blank-${i}`} />)}{Array.from({ length: days }).map((_, i) => {
          const d = String(i + 1).padStart(2, '0'); const key = `${month}-${d}`; const selected = key === selectedDate;
          return <button key={key} className={`${selected ? 'selected' : ''} ${dateCounts.has(key) ? 'has-event' : ''}`} onClick={() => setSelectedDate(key)}>{i + 1}{dateCounts.has(key) && <i />}</button>;
        })}</div>
        <div className="px-calendar-legend"><span><i /> Scheduled activity</span><span><i className="active-dot" /> Selected date</span></div>
        {upcomingExams.length > 0 && <div className="px-upcoming"><strong>Upcoming examinations</strong>{upcomingExams.map((exam) => <div key={exam.id}><span>{exam.title}</span><small>{prettyDate(exam.date)}{exam.subject ? ` · ${exam.subject}` : ''}</small></div>)}</div>}
      </section>
      <section className="panel px-day-panel">
        <div className="panel-head"><div><h2>{prettyDate(selectedDate)}</h2><span className="muted small">Selected date</span></div><button className="chip-btn" onClick={() => { setForm((v) => ({ ...v, date: selectedDate })); setShowForm(true); }}>+ Add</button></div>
        {showForm && <form className="px-form" onSubmit={addItem}>
          <Field label="Title"><input required maxLength={100} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="e.g. Revise algebra exercises" /></Field>
          <div className="px-form-grid"><Field label="Type"><select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>{['Homework', 'Examination', 'Event', 'Personal task', 'Study'].map((x) => <option key={x}>{x}</option>)}</select></Field><Field label="Date"><input required type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></Field></div>
          <div className="px-form-grid"><Field label="Time"><input type="time" value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })} /></Field><Field label="Priority"><select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}>{['Low', 'Medium', 'High'].map((x) => <option key={x}>{x}</option>)}</select></Field></div>
          <div className="px-form-grid"><Field label="Repeat"><select value={form.repeat} onChange={(e) => setForm({ ...form, repeat: e.target.value })}>{['Never', 'Daily', 'Weekly'].map((x) => <option key={x}>{x}</option>)}</select></Field><Field label="Reminder"><select value={form.reminder} onChange={(e) => setForm({ ...form, reminder: e.target.value })}>{['None', 'At time', '10 minutes before', '1 day before'].map((x) => <option key={x}>{x}</option>)}</select></Field></div>
          <div className="actions-row"><button className="btn btn-primary" type="submit">Save task</button><button className="text-btn" type="button" onClick={() => setShowForm(false)}>Cancel</button></div>
        </form>}
        {itemsForDate.length === 0 && !showForm ? <p className="muted px-muted-space">Nothing scheduled for this date yet.</p> : <div className="px-task-list">{itemsForDate.map((item) => <div className={`px-task ${item.occurrenceCompleted ? 'completed' : ''}`} key={`${item.id}-${selectedDate}`}><button className="px-check" onClick={() => toggleItem(item.id, selectedDate)} aria-label={item.occurrenceCompleted ? 'Mark incomplete' : 'Mark complete'}>{item.occurrenceCompleted ? '✓' : ''}</button><div><strong>{item.title}</strong><small>{item.type} · {item.time || 'Any time'} · {item.priority} priority{item.repeat !== 'Never' ? ` · ${item.repeat}` : ''}</small></div><button className="px-remove" onClick={() => removeItem(item.id)} aria-label="Delete task">×</button></div>)}</div>}
      </section>
    </div>
    <section className="panel px-planner">
      <div className="panel-head"><div><h2>Smart study planner</h2><p className="muted small">Rule-based timetable using your difficult subjects, unfinished chapters and upcoming exams. No AI is used.</p></div><span className="count-chip">Editable draft</span></div>
      <div className="px-planner-controls"><Field label="Study hours per day"><input type="number" min="0.5" max="6" step="0.5" value={planHours} onChange={(e) => setPlanHours(Math.max(0.5, Math.min(6, Number(e.target.value) || 0.5)))} /></Field><button className="btn btn-soft" onClick={generatePlanner}>Generate 7-day plan</button></div>
      {planner.length > 0 && <><div className="px-plan-list">{planner.slice(0, 14).map((block) => <div key={block.id}><strong>{block.title}</strong><small>{prettyDate(block.date)} · {block.time} · 30 min</small></div>)}</div><div className="actions-row"><button className="btn btn-primary" onClick={applyPlanner}>Add timetable to calendar</button><button className="text-btn" onClick={() => setPlanner([])}>Discard draft</button></div></>}
      <div className="px-league-strip"><span>Weekly league: <strong>{league}</strong></span><span>{currentWeekPoints.toLocaleString('en-IN')} points this week</span></div>
    </section>
  </>;
}

function TrackerModule({ state, update, subjects, allChapters, showMessage }) {
  const [subject, setSubject] = useState(subjects[0]?.name || '');
  const chapters = allChapters.filter((x) => x.subject === subject);
  const [chapter, setChapter] = useState('');
  const [topic, setTopic] = useState('');
  const [numbers, setNumbers] = useState('1–20');
  const filtered = state.trackerRecords.filter((r) => r.subject === subject && (!chapter || r.chapter === chapter));
  const correct = filtered.filter((r) => r.status === 'Correct').length;
  const incorrect = filtered.filter((r) => r.status === 'Incorrect').length;
  const unattempted = filtered.filter((r) => r.status === 'Unattempted').length;
  const totalAnswered = correct + incorrect;
  const accuracy = totalAnswered ? Math.round(correct / totalAnswered * 100) : 0;
  function parseNumbers(value) {
    const list = new Set();
    for (const part of value.split(',')) {
      const segment = part.trim().replace(/[–—]/g, '-');
      const range = segment.match(/^(\d+)\s*-\s*(\d+)$/);
      if (range) {
        const from = Number(range[1]); const to = Number(range[2]);
        if (to < from || to - from > 300) throw new Error('Ranges must be ascending and contain at most 301 questions.');
        for (let n = from; n <= to; n += 1) list.add(n);
      } else if (/^\d+$/.test(segment)) list.add(Number(segment));
      else if (segment) throw new Error(`Invalid question entry: ${segment}`);
    }
    if (!list.size || list.size > 301 || [...list].some((n) => n < 1 || n > 10000)) throw new Error('Enter question numbers from 1 to 10,000.');
    return [...list].sort((a, b) => a - b);
  }
  function addQuestions(event) {
    event.preventDefault();
    try {
      if (!subject || !chapter || !safeText(topic, 80)) throw new Error('Choose a subject, chapter and topic.');
      const ids = parseNumbers(numbers);
      const existing = new Set(state.trackerRecords.map((r) => r.key));
      const records = ids.filter((n) => !existing.has(`${subject}|${chapter}|${safeText(topic, 80)}|${n}`)).map((n) => ({ key: `${subject}|${chapter}|${safeText(topic, 80)}|${n}`, id: uid(), subject, chapter, topic: safeText(topic, 80), number: n, status: 'Unattempted', createdAt: Date.now(), history: [{ status: 'Unattempted', source: 'manual', createdAt: Date.now() }] }));
      update((prev) => ({ trackerRecords: [...(prev.trackerRecords || []), ...records] }));
      setNumbers('');
      showMessage(`${records.length} question${records.length === 1 ? '' : 's'} added. Existing questions were skipped.`);
    } catch (error) { showMessage(error.message); }
  }
  function setStatus(record, status) {
    const changedAt = Date.now();
    update((prev) => ({
      trackerRecords: prev.trackerRecords.map((r) => r.key === record.key ? { ...r, status, updatedAt: changedAt, history: [...(r.history || []), { status, source: 'manual', createdAt: changedAt }] } : r),
      doubtDetails: { ...(prev.doubtDetails || {}), [record.key]: { ...(prev.doubtDetails?.[record.key] || {}), resolved: status === 'Correct', originalStatus: status, updatedAt: changedAt } },
    }));
  }
  const byTopic = Object.values(filtered.reduce((acc, row) => { acc[row.topic] ||= { topic: row.topic, rows: [] }; acc[row.topic].rows.push(row); return acc; }, {}));
  return <>
    <ModuleHead title="Progress tracker." description="Record question numbers at topic level. Incorrect and unattempted items automatically appear in Doubts & Review." />
    <section className="scoreboard px-stat-strip"><div className="score"><b>{filtered.length}</b><span>Tracked questions</span></div><div className="score"><b>{correct}</b><span>Correct</span></div><div className="score"><b>{incorrect}</b><span>Incorrect</span></div><div className="score"><b>{accuracy}%</b><span>Accuracy · {unattempted} unattempted</span></div></section>
    <section className="panel">
      <div className="panel-head"><h2>Add question range</h2><span className="count-chip">e.g. 1, 3, 6 or 1–100</span></div>
      <form className="px-form" onSubmit={addQuestions}>
        <div className="px-form-grid"><Field label="Subject"><select value={subject} onChange={(e) => { setSubject(e.target.value); setChapter(''); }}>{subjects.map((s) => <option key={s.id} value={s.name}>{s.name}</option>)}</select></Field><Field label="Chapter"><select value={chapter} onChange={(e) => setChapter(e.target.value)}><option value="">All chapters</option>{chapters.map((c) => <option key={c.id}>{c.title}</option>)}</select></Field></div>
        <div className="px-form-grid"><Field label="Topic"><input value={topic} onChange={(e) => setTopic(e.target.value)} maxLength={80} placeholder="e.g. Linear equations" /></Field><Field label="Question numbers or ranges"><input value={numbers} onChange={(e) => setNumbers(e.target.value)} placeholder="1, 3, 6, 8, 17–25" /></Field></div>
        <button className="btn btn-primary" type="submit">Add questions to tracker</button>
      </form>
    </section>
    <section className="panel px-topic-panel"><div className="panel-head"><h2>{subject || 'Subject'} questions</h2><span className="count-chip">{filtered.length} recorded</span></div>
      {byTopic.length === 0 ? <p className="muted">No questions tracked for this subject and chapter yet.</p> : byTopic.map((group) => <div className="px-topic-group" key={group.topic}><div className="px-topic-head"><strong>{group.topic}</strong><small>{group.rows.filter((r) => r.status === 'Correct').length}/{group.rows.length} correct</small></div><div className="px-question-grid">{group.rows.sort((a, b) => a.number - b.number).map((row) => <div className={`px-qcell ${row.status.toLowerCase()}`} key={row.key} title={`${row.history?.length || 0} status record(s)`}><b>{row.number}</b><select aria-label={`Question ${row.number} status`} value={row.status} onChange={(e) => setStatus(row, e.target.value)}><option>Unattempted</option><option>Correct</option><option>Incorrect</option></select></div>)}</div></div>)}
    </section>
  </>;
}

function DoubtsModule({ state, update, showMessage, onNavigate }) {
  const trackerDoubts = state.trackerRecords.filter((r) => r.status !== 'Correct' && !state.doubtDetails?.[r.key]?.resolved);
  const trackerHistory = state.trackerRecords.filter((r) => state.doubtDetails?.[r.key]?.resolved);
  const trackedQuestionIds = new Set(state.trackerRecords.map((record) => record.questionId).filter(Boolean));
  const oldRevision = (state.revisionItems || []).filter((r) => !r.resolved && !trackedQuestionIds.has(r.questionId));
  const [selected, setSelected] = useState('Open');
  function editDetail(key, patch) { update((prev) => ({ doubtDetails: { ...(prev.doubtDetails || {}), [key]: { ...(prev.doubtDetails?.[key] || {}), ...patch } } })); }
  function resolve(record) { editDetail(record.key, { resolved: true, resolvedAt: Date.now() }); showMessage('Marked as resolved.'); }
  const all = selected === 'Resolved' ? trackerHistory : trackerDoubts;
  return <>
    <ModuleHead title="Doubts & review." description="Incorrect and unattempted questions are collected here from the tracker. Practice mistakes are included too." />
    <div className="px-toggle-row"><button className={selected === 'Open' ? 'on' : ''} onClick={() => setSelected('Open')}>Open doubts ({trackerDoubts.length + oldRevision.length})</button><button className={selected === 'Resolved' ? 'on' : ''} onClick={() => setSelected('Resolved')}>Resolved ({trackerHistory.length})</button></div>
    {selected === 'Open' && oldRevision.length > 0 && <section className="panel"><div className="panel-head"><h2>Practice and lesson mistakes</h2><button className="text-btn" onClick={() => onNavigate('Revision')}>Open revision list<Icon name="arrow" size={15} /></button></div>{oldRevision.map((item) => <div className="px-doubt" key={item.questionId}><div><strong>{item.snapshot?.topic || item.questionId}</strong><small>{item.snapshot?.prompt || 'Question from your practice history'} · {item.mistakes} incorrect attempt(s)</small></div><span className="tag warn">Review</span></div>)}</section>}
    {all.length === 0 ? <Empty title={selected === 'Open' ? 'No open tracker doubts.' : 'Nothing resolved yet.'} detail={selected === 'Open' ? 'Mark questions as incorrect or unattempted in Progress Tracker and they will appear here automatically.' : 'Resolved tracker questions will be listed here.'} action={<button className="btn btn-primary" onClick={() => onNavigate('Tracker')}>Open Progress Tracker</button>} /> : <section className="px-doubt-list">{all.map((record) => {
      const details = state.doubtDetails?.[record.key] || {};
      return <article className="panel px-doubt-card" key={record.key}><div className="rev-top"><span className="lesson-badge">{record.subject} · {record.chapter}</span><span className="due">Question {record.number} · {record.status}</span></div><h3>{record.topic}</h3><div className="px-form-grid"><Field label="Student notes"><textarea rows={2} value={details.notes || ''} onChange={(e) => editDetail(record.key, { notes: e.target.value.slice(0, 1000) })} placeholder="What confused you?" /></Field><Field label="Personal explanation"><textarea rows={2} value={details.explanation || ''} onChange={(e) => editDetail(record.key, { explanation: e.target.value.slice(0, 1500) })} placeholder="Write the solution in your own words" /></Field></div>{selected === 'Open' ? <button className="btn btn-complete" onClick={() => resolve(record)}>Mark resolved</button> : <button className="text-btn" onClick={() => editDetail(record.key, { resolved: false })}>Reopen doubt</button>}</article>;
    })}</section>}
  </>;
}

function ArchiveModule({ state, update, userId, search, setSearch, busy, setBusy, showMessage }) {
  const [folder, setFolder] = useState('All files');
  const [newFolder, setNewFolder] = useState('');
  const [showFolderForm, setShowFolderForm] = useState(false);
  const [preview, setPreview] = useState(null);
  const [renaming, setRenaming] = useState(null);
  const files = state.archiveFiles.filter((file) => (folder === 'All files' || file.folder === folder) && `${file.name} ${file.originalName} ${file.folder}`.toLowerCase().includes(search.toLowerCase())).sort((a, b) => b.createdAt - a.createdAt);
  const used = state.archiveFiles.reduce((total, f) => total + (f.size || 0), 0);
  const prettySize = (n) => n < 1024 * 1024 ? `${Math.max(1, Math.round(n / 1024))} KB` : `${(n / 1024 / 1024).toFixed(1)} MB`;
  async function upload(event) {
    const selected = Array.from(event.target.files || []);
    event.target.value = '';
    if (!selected.length) return;
    if (!userId) return showMessage('Sign in to upload private archive files.');
    setBusy(true);
    try {
      for (const file of selected) {
        const ext = file.name.split('.').pop()?.toLowerCase() || '';
        if (!ALLOWED_EXTENSIONS.has(ext)) throw new Error(`${file.name}: unsupported format.`);
        if (file.size > MAX_FILE_SIZE) throw new Error(`${file.name}: maximum file size is 20 MB.`);
        const path = `${userId}/${uid()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`;
        const { error } = await supabase.storage.from(BUCKET).upload(path, file, { contentType: file.type || 'application/octet-stream', upsert: false });
        if (error) throw error;
        const record = { id: uid(), name: file.name, originalName: file.name, path, size: file.size, mimeType: file.type, folder: folder === 'All files' ? 'My Materials' : folder, createdAt: Date.now() };
        update((prev) => ({ archiveFiles: [...(prev.archiveFiles || []), record] }));
      }
      showMessage('Upload complete. Files are private to your account.');
    } catch (error) { showMessage(error.message || 'Upload failed.'); }
    finally { setBusy(false); }
  }
  async function signedFileUrl(file) {
    const { data, error } = await supabase.storage.from(BUCKET).createSignedUrl(file.path, 60 * 5);
    if (error) throw error;
    return data.signedUrl;
  }
  async function openFile(file) {
    try {
      if (file.mimeType === 'text/plain') {
        const { data, error } = await supabase.storage.from(BUCKET).download(file.path);
        if (error) throw error;
        setPreview({ ...file, text: (await data.text()).slice(0, 200_000) });
        return;
      }
      const url = await signedFileUrl(file);
      if (file.mimeType?.startsWith('image/') || file.mimeType === 'application/pdf') setPreview({ ...file, url });
      else window.open(url, '_blank', 'noopener,noreferrer');
    } catch (error) { showMessage(error.message || 'Could not open this file.'); }
  }
  async function downloadFile(file) {
    try {
      const { data, error } = await supabase.storage.from(BUCKET).download(file.path);
      if (error) throw error;
      const url = URL.createObjectURL(data);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = file.name;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 30_000);
    } catch (error) { showMessage(error.message || 'Could not download this file.'); }
  }
  async function removeFile(file) {
    if (!window.confirm(`Delete ${file.name} from your archive?`)) return;
    try {
      const { error } = await supabase.storage.from(BUCKET).remove([file.path]);
      if (error) throw error;
      update((prev) => ({ archiveFiles: prev.archiveFiles.filter((f) => f.id !== file.id) }));
      showMessage('File deleted.');
    } catch (error) { showMessage(error.message || 'Could not delete the file.'); }
  }
  function addFolder(event) {
    event.preventDefault();
    const name = safeText(newFolder, 60).replace(/[\\/]/g, '').trim();
    if (!name) return;
    if ((state.archiveFolders || []).includes(name)) return showMessage('That folder already exists.');
    update((prev) => ({ archiveFolders: [...(prev.archiveFolders || []), name] }));
    setNewFolder(''); setShowFolderForm(false); setFolder(name);
  }
  function moveFile(file, nextFolder) { update((prev) => ({ archiveFiles: prev.archiveFiles.map((f) => f.id === file.id ? { ...f, folder: nextFolder } : f) })); }
  return <>
    <ModuleHead title="Personal archive." description="Keep your study files organised in private folders and subfolders. Preview PDFs and images, or download your files." action={<label className="btn btn-primary px-upload-label"><Icon name="upload" size={17} />{busy ? 'Uploading…' : 'Upload files'}<input type="file" multiple accept=".pdf,.doc,.docx,.ppt,.pptx,.png,.jpg,.jpeg,.webp,.gif,.txt" onChange={upload} disabled={busy} /></label>} />
    <section className="panel px-archive-summary"><div><strong>{state.archiveFiles.length} files</strong><small>{prettySize(used)} used · 20 MB maximum per file</small></div><div className="bar"><span style={{ width: `${Math.min(100, used / (250 * 1024 * 1024) * 100)}%` }} /></div><button className="text-btn" onClick={() => setShowFolderForm((v) => !v)}>+ New folder</button></section>
    {showFolderForm && <form className="panel px-inline-form" onSubmit={addFolder}><Field label="Folder name"><input required maxLength={60} value={newFolder} onChange={(e) => setNewFolder(e.target.value)} placeholder="e.g. Science / Physics / Chapter 1" /></Field><button className="btn btn-primary">Create folder</button></form>}
    <div className="px-archive-layout"><aside className="panel px-folders"><h2>Folders</h2><button className={folder === 'All files' ? 'active' : ''} onClick={() => setFolder('All files')}>All files <span>{state.archiveFiles.length}</span></button>{(state.archiveFolders || []).map((name) => <button key={name} className={folder === name ? 'active' : ''} onClick={() => setFolder(name)}>📁 {name}<span>{state.archiveFiles.filter((f) => f.folder === name).length}</span></button>)}</aside>
      <section className="panel px-files"><div className="panel-head"><h2>{folder}</h2><input className="px-search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search files…" /></div>
        {files.length === 0 ? <p className="muted">No files found here. Upload a study material to get started.</p> : files.map((file) => <div className="px-file-row" key={file.id}><div className="px-file-icon">{file.mimeType?.startsWith('image/') ? '🖼️' : file.mimeType === 'application/pdf' ? '📕' : '📄'}</div><div className="px-file-details"><strong>{file.name}</strong><small>{prettySize(file.size)} · {new Date(file.createdAt).toLocaleDateString('en-IN')} · {file.folder}</small></div><select aria-label={`Move ${file.name}`} value={file.folder} onChange={(e) => moveFile(file, e.target.value)}>{(state.archiveFolders || []).map((x) => <option key={x}>{x}</option>)}</select><button className="chip-btn" onClick={() => openFile(file)}>Open</button><button className="chip-btn" onClick={() => downloadFile(file)}>Download</button><button className="chip-btn" onClick={() => setRenaming({ id: file.id, name: file.name })}>Rename</button><button className="px-remove" onClick={() => removeFile(file)} aria-label={`Delete ${file.name}`}>×</button></div>)}
      </section></div>
    {renaming && <div className="px-modal-backdrop"><form className="panel px-modal" onSubmit={(e) => { e.preventDefault(); update((prev) => ({ archiveFiles: prev.archiveFiles.map((f) => f.id === renaming.id ? { ...f, name: safeText(renaming.name, 150) } : f) })); setRenaming(null); }}><h2>Rename file</h2><Field label="File name"><input value={renaming.name} onChange={(e) => setRenaming({ ...renaming, name: e.target.value })} required maxLength={150} /></Field><div className="actions-row"><button className="btn btn-primary">Save name</button><button type="button" className="text-btn" onClick={() => setRenaming(null)}>Cancel</button></div></form></div>}
    {preview && <div className="px-modal-backdrop" onClick={() => setPreview(null)}><div className="panel px-preview" onClick={(e) => e.stopPropagation()}><div className="panel-head"><h2>{preview.name}</h2><button className="chip-btn" onClick={() => setPreview(null)}>Close</button></div>{preview.mimeType?.startsWith('image/') ? <img src={preview.url} alt={preview.name} /> : preview.mimeType === 'text/plain' ? <pre className="px-text-preview">{preview.text}</pre> : <iframe title={preview.name} src={preview.url} />}</div></div>}
  </>;
}

function TestsModule({ state, update, subjects, settings, showMessage, onNavigate }) {
  const [mode, setMode] = useState('Chapter practice');
  const [active, setActive] = useState(false);
  const [index, setIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [marked, setMarked] = useState([]);
  const [seconds, setSeconds] = useState(20 * 60);
  const [submitted, setSubmitted] = useState(false);
  const [startedAt, setStartedAt] = useState(null);
  const bank = questions;
  useEffect(() => {
    if (!active || submitted) return undefined;
    const timer = window.setInterval(() => setSeconds((s) => Math.max(0, s - 1)), 1000);
    return () => window.clearInterval(timer);
  }, [active, submitted]);
  useEffect(() => { if (active && seconds === 0 && !submitted) finish(); }, [seconds, active, submitted]);
  const duration = mode === 'Timed mock examination' ? 45 * 60 : mode === 'Full available practice set' ? 25 * 60 : 20 * 60;
  function start() { setAnswers({}); setMarked([]); setIndex(0); setSeconds(duration); setSubmitted(false); setStartedAt(Date.now()); setActive(true); }
  function finish() {
    if (submitted || !active) return;
    const score = bank.filter((q) => answers[q.id] === q.answer).length;
    const wrong = bank.filter((q) => answers[q.id] !== undefined && answers[q.id] !== q.answer);
    const snapshots = wrong.map((q) => ({ questionId: q.id, snapshot: { prompt: q.prompt, topic: q.topic, chapterId: 'class-10-quadratics' } }));
    const result = { id: uid(), mode, score, total: bank.length, accuracy: Math.round(score / bank.length * 100), submittedAt: Date.now(), durationSeconds: Math.max(0, duration - seconds), correct: score, incorrect: wrong.length, unattempted: bank.filter((q) => answers[q.id] === undefined).length };
    update((prev) => {
      let revisionItems = [...(prev.revisionItems || [])];
      let next = { ...prev };
      snapshots.forEach(({ questionId, snapshot }) => {
        const found = revisionItems.find((r) => r.questionId === questionId);
        if (found) revisionItems = revisionItems.map((r) => r.questionId === questionId ? { ...r, mistakes: found.mistakes + 1, dueAt: Date.now(), reviewedAt: null, snapshot } : r);
        else revisionItems.push({ questionId, snapshot, mistakes: 1, dueAt: Date.now(), reviewedAt: null });
      });
      const attempts = [...(prev.attempts || [])];
      const trackerRecords = [...(prev.trackerRecords || [])];
      const doubtDetails = { ...(prev.doubtDetails || {}) };
      bank.forEach((question, questionIndex) => {
        const selected = answers[question.id];
        const correct = selected !== undefined && selected === question.answer;
        if (correct) revisionItems = revisionItems.filter((item) => item.questionId !== question.id);
        if (selected !== undefined) {
          attempts.push({ id: uid(), questionId: question.id, topic: question.topic, selected, correct, source: 'test', createdAt: Date.now() });
          next = { ...next, ...awardOnce(next, `practice-question:${question.id}`, 5) };
        }
        const number = questionIndex + 1;
        const key = `Mathematics|Quadratic Equations|${question.topic}|${number}`;
        const status = selected === undefined ? 'Unattempted' : correct ? 'Correct' : 'Incorrect';
        const changedAt = Date.now();
        const existingIndex = trackerRecords.findIndex((entry) => entry.key === key);
        const historyEntry = { status, source: 'test', createdAt: changedAt, testId: result.id };
        if (existingIndex >= 0) {
          const old = trackerRecords[existingIndex];
          trackerRecords[existingIndex] = { ...old, questionId: question.id, status, updatedAt: changedAt, history: [...(old.history || []), historyEntry] };
        } else {
          trackerRecords.push({ key, id: `${question.id}-tracker`, questionId: question.id, subject: 'Mathematics', chapter: 'Quadratic Equations', topic: question.topic, number, status, createdAt: changedAt, updatedAt: changedAt, history: [historyEntry] });
        }
        doubtDetails[key] = { ...(doubtDetails[key] || {}), resolved: status === 'Correct', originalStatus: status, updatedAt: changedAt };
      });
      if (mode === 'Chapter challenge') next = { ...next, ...awardOnce(next, 'chapter-challenge:class-10-quadratics', 20) };
      return { ...next, attempts, trackerRecords, doubtDetails, testResults: [...(prev.testResults || []), { ...result, answers: bank.map((question) => ({ questionId: question.id, selected: answers[question.id] ?? null, correct: answers[question.id] === question.answer })) }], revisionItems, assessmentCount: (prev.assessmentCount || 0) + 1, bestAssessment: Math.max(prev.bestAssessment || 0, result.accuracy) };
    });
    setActive(false); setSubmitted(true);
  }
  const q = bank[index];
  const accuracy = state.testResults.length ? Math.round(state.testResults.reduce((s, r) => s + r.accuracy, 0) / state.testResults.length) : 0;
  return <>
    <ModuleHead title="Tests & examination centre." description="Take practice quizzes and timed mock tests from the curated question bank. Results feed your progress and Doubts & Review." />
    <section className="scoreboard px-stat-strip"><div className="score"><b>{state.testResults.length}</b><span>Tests completed</span></div><div className="score"><b>{state.testResults.reduce((s, r) => s + r.correct, 0)}</b><span>Correct answers</span></div><div className="score"><b>{accuracy}%</b><span>Average accuracy</span></div><div className="score"><b>{state.testResults.reduce((s, r) => s + r.durationSeconds, 0) ? Math.round(state.testResults.reduce((s, r) => s + r.durationSeconds, 0) / 60) : 0} min</b><span>Test time</span></div></section>
    {!active && !submitted && <section className="panel px-test-start"><div className="sheet-stack"><div className="sheet s3" /><div className="sheet s2" /><div className="sheet s1"><small>PATHSHALAX TEST</small><strong>Think.<br />Try.<br />Grow.</strong><em>Managed question bank</em><Icon name="assess" size={40} /></div></div><div className="exam-copy"><h2>Choose your test mode.</h2><p className="muted">Questions are loaded from the existing, manually managed Class 10 Mathematics — Quadratic Equations bank. No questions are generated by AI.</p><Field label="Test type"><select value={mode} onChange={(e) => setMode(e.target.value)}>{['Chapter practice', 'Chapter challenge', 'Full available practice set', 'Timed mock examination'].map((x) => <option>{x}</option>)}</select></Field><div className="facts"><span><b>{bank.length}</b>Questions</span><span><b>{duration / 60}</b>Minutes</span><span><b>MCQ</b>Format</span></div><button className="btn btn-primary" onClick={start}>Start examination<Icon name="arrow" size={17} /></button></div></section>}
    {active && q && <section className="panel px-test-view"><div className="px-test-toolbar"><span className="lesson-badge">{mode}</span><span className="px-test-clock">⏱ {String(Math.floor(seconds / 60)).padStart(2, '0')}:{String(seconds % 60).padStart(2, '0')}</span></div><div className="bar"><span style={{ width: `${(Object.keys(answers).length / bank.length) * 100}%` }} /></div><div className="px-test-body"><aside className="px-test-index"><strong>Question map</strong><div>{bank.map((item, i) => <button key={item.id} onClick={() => setIndex(i)} className={`${index === i ? 'current' : ''} ${answers[item.id] !== undefined ? 'answered' : ''} ${marked.includes(item.id) ? 'marked' : ''}`}>{i + 1}</button>)}</div><small>{Object.keys(answers).length}/{bank.length} answered</small></aside><article className="px-test-question"><div className="q-top"><span className="count-chip">Question {index + 1} of {bank.length}</span><button className="text-btn" onClick={() => setMarked((v) => v.includes(q.id) ? v.filter((x) => x !== q.id) : [...v, q.id])}>{marked.includes(q.id) ? '★ Marked for review' : '☆ Mark for review'}</button></div><h2 className="q-prompt">{q.prompt}</h2><div className="options">{q.options.map((option, i) => <button className={`opt ${answers[q.id] === i ? 'chosen' : ''}`} key={i} onClick={() => setAnswers((v) => ({ ...v, [q.id]: i }))}><span className="opt-letter">{String.fromCharCode(65 + i)}</span><span className="opt-text">{option}</span></button>)}</div><div className="q-actions"><button className="btn btn-soft" disabled={index === 0} onClick={() => setIndex((v) => v - 1)}>Previous</button><button className="btn btn-soft" disabled={index === bank.length - 1} onClick={() => setIndex((v) => v + 1)}>Next</button><button className="btn btn-primary" onClick={() => { if (window.confirm('Submit this test now?')) finish(); }}>Submit test</button></div></article></div></section>}
    {submitted && <section className="panel px-result"><div className="done-symbol"><Icon name="trophy" size={42} /></div><h2>Test submitted.</h2><p className="muted">Your result and question history have been saved.</p><div className="facts"><span><b>{state.testResults.at(-1)?.score ?? 0}/{state.testResults.at(-1)?.total ?? bank.length}</b>Correct</span><span><b>{state.testResults.at(-1)?.accuracy ?? 0}%</b>Accuracy</span><span><b>{state.testResults.at(-1)?.incorrect ?? 0}</b>Incorrect</span><span><b>{state.testResults.at(-1)?.unattempted ?? 0}</b>Unattempted</span></div><button className="btn btn-primary" onClick={start}>Take another test</button><button className="btn btn-soft" onClick={() => { setSubmitted(false); onNavigate?.('Doubts'); }}>Review mistakes</button></section>}
    <section className="panel px-history"><div className="panel-head"><h2>Test history</h2><span className="count-chip">{state.testResults.length} saved</span></div>{state.testResults.length === 0 ? <p className="muted">Your completed tests will appear here.</p> : [...state.testResults].reverse().map((result) => <div className="px-history-row" key={result.id}><div><strong>{result.mode}</strong><small>{new Date(result.submittedAt).toLocaleString('en-IN')} · {result.durationSeconds} seconds</small></div><b>{result.accuracy}%</b></div>)}</section>
  </>;
}

function NotesModule({ state, update, subjects, allChapters, search, setSearch, showMessage }) {
  const [kind, setKind] = useState('Note');
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ title: '', body: '', subject: subjects[0]?.name || '', chapter: '', topic: '', bookmarked: false });
  const items = state.notes.filter((item) => `${item.title} ${item.body} ${item.subject} ${item.chapter} ${item.topic}`.toLowerCase().includes(search.toLowerCase()) && (kind === 'All' || item.kind === kind));
  function save(event) {
    event.preventDefault();
    if (!safeText(form.title, 100) || !safeText(form.body, 8000)) return showMessage('Add a title and content before saving.');
    const record = { ...form, title: safeText(form.title, 100), body: safeText(form.body, 8000), id: editing || uid(), kind, updatedAt: Date.now() };
    update((prev) => ({ notes: editing ? prev.notes.map((n) => n.id === editing ? record : n) : [...(prev.notes || []), record] }));
    setForm({ title: '', body: '', subject: subjects[0]?.name || '', chapter: '', topic: '', bookmarked: false }); setEditing(null); showMessage('Saved to your notes.');
  }
  function edit(note) { setEditing(note.id); setKind(note.kind); setForm({ title: note.title, body: note.body, subject: note.subject || '', chapter: note.chapter || '', topic: note.topic || '', bookmarked: note.bookmarked }); window.scrollTo({ top: 0, behavior: 'smooth' }); }
  function remove(id) { if (window.confirm('Delete this revision item?')) update((prev) => ({ notes: prev.notes.filter((n) => n.id !== id) })); }
  function bookmark(id) { update((prev) => ({ notes: prev.notes.map((n) => n.id === id ? { ...n, bookmarked: !n.bookmarked } : n) })); }
  const chapters = allChapters.filter((c) => c.subject === form.subject);
  return <>
    <ModuleHead title="Notes & smart revision." description="Create your own notes, flashcards, formula sheets and definitions, then organise them by subject and chapter." />
    <section className="panel px-note-editor"><div className="panel-head"><h2>{editing ? 'Edit study material' : 'Create study material'}</h2><span className="count-chip">Student-created content</span></div><form className="px-form" onSubmit={save}><div className="px-toggle-row">{['Note', 'Flashcard', 'Formula', 'Definition', 'Revision sheet'].map((x) => <button type="button" className={kind === x ? 'on' : ''} onClick={() => setKind(x)} key={x}>{x}</button>)}</div><Field label="Title"><input required maxLength={100} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder={kind === 'Flashcard' ? 'Question or term' : 'A clear title'} /></Field><div className="px-form-grid"><Field label="Subject"><select value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value, chapter: '' })}>{subjects.map((s) => <option>{s.name}</option>)}</select></Field><Field label="Chapter"><select value={form.chapter} onChange={(e) => setForm({ ...form, chapter: e.target.value })}><option value="">Not linked</option>{chapters.map((c) => <option>{c.title}</option>)}</select></Field><Field label="Topic"><input value={form.topic} onChange={(e) => setForm({ ...form, topic: e.target.value })} maxLength={80} /></Field></div><Field label={kind === 'Flashcard' ? 'Answer / back of card' : 'Content'}><textarea rows={5} required maxLength={8000} value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} placeholder="Write your own explanation, key facts or steps…" /></Field><div className="actions-row"><button className="btn btn-primary">{editing ? 'Save changes' : 'Save material'}</button>{editing && <button type="button" className="text-btn" onClick={() => { setEditing(null); setForm({ title: '', body: '', subject: subjects[0]?.name || '', chapter: '', topic: '', bookmarked: false }); }}>Cancel edit</button>}</div></form></section>
    <section className="panel px-note-list"><div className="panel-head"><h2>Your revision library</h2><input className="px-search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search notes…" /></div><div className="px-toggle-row">{['All', 'Note', 'Flashcard', 'Formula', 'Definition', 'Revision sheet'].map((x) => <button key={x} className={kind === x ? 'on' : ''} onClick={() => setKind(x)}>{x}</button>)}</div>
      {items.length === 0 ? <p className="muted">No materials match this view. Create your first note above.</p> : <div className="px-note-grid">{items.map((item) => <article className="px-note-card" key={item.id}><div className="rev-top"><span className="lesson-badge">{item.kind}</span><button className="text-btn" onClick={() => bookmark(item.id)}>{item.bookmarked ? '★ Bookmarked' : '☆ Bookmark'}</button></div><h3>{item.title}</h3><small>{[item.subject, item.chapter, item.topic].filter(Boolean).join(' · ')}</small><p>{item.body}</p><div className="actions-row"><button className="chip-btn" onClick={() => edit(item)}>Edit</button><button className="text-btn" onClick={() => remove(item.id)}>Delete</button></div></article>)}</div>}
    </section>
  </>;
}

function TimerModule({ state, update, subjects, allChapters, now, setNow, showMessage }) {
  const active = state.activeTimer || null;
  const [subject, setSubject] = useState(subjects[0]?.name || '');
  const [chapter, setChapter] = useState('');
  useEffect(() => { const id = window.setInterval(() => setNow(Date.now()), 1000); return () => window.clearInterval(id); }, [setNow]);
  const currentSegment = active?.status === 'running' ? Math.max(0, Math.floor((now - active.segmentStartedAt) / 1000)) : 0;
  const focusSeconds = (active?.focusSeconds || 0) + (active?.status === 'running' && !active?.isBreak ? currentSegment : 0);
  const breakSeconds = (active?.breakSeconds || 0) + (active?.status === 'running' && active?.isBreak ? currentSegment : 0);
  const totalSeconds = focusSeconds + breakSeconds;
  const todayStudy = state.studySessions.filter((s) => s.date === dateKey()).reduce((sum, s) => sum + s.focusSeconds, 0);
  const weekStudy = state.studySessions.filter((s) => s.date >= weekKey()).reduce((sum, s) => sum + s.focusSeconds, 0);
  const sessionsBySubject = subjects.map((s) => ({ ...s, seconds: state.studySessions.filter((x) => x.subject === s.name).reduce((sum, x) => sum + x.focusSeconds, 0) })).filter((x) => x.seconds > 0);
  function accumulate(prev, status = prev.status, isBreak = prev.isBreak) {
    const elapsed = prev.status === 'running' ? Math.max(0, Math.floor((Date.now() - prev.segmentStartedAt) / 1000)) : 0;
    return { ...prev, focusSeconds: (prev.focusSeconds || 0) + (!prev.isBreak && prev.status === 'running' ? elapsed : 0), breakSeconds: (prev.breakSeconds || 0) + (prev.isBreak && prev.status === 'running' ? elapsed : 0), status, isBreak, segmentStartedAt: status === 'running' ? Date.now() : null };
  }
  function start() { if (!active) update({ activeTimer: { status: 'running', isBreak: false, subject, chapter, focusSeconds: 0, breakSeconds: 0, startedAt: Date.now(), segmentStartedAt: Date.now() } }); }
  function pause() { if (active) update({ activeTimer: accumulate(active, 'paused') }); }
  function resume() { if (active) update({ activeTimer: { ...active, status: 'running', segmentStartedAt: Date.now() } }); }
  function toggleBreak() { if (active) update({ activeTimer: accumulate(active, 'running', !active.isBreak) }); }
  function stop() {
    if (!active) return;
    const final = accumulate(active, 'paused');
    const session = { id: uid(), subject: active.subject, chapter: active.chapter, focusSeconds: final.focusSeconds, breakSeconds: final.breakSeconds, startedAt: active.startedAt, endedAt: Date.now(), date: dateKey() };
    if (session.focusSeconds < 60) { update({ activeTimer: null }); return showMessage('Session under one minute was not added to study totals.'); }
    update((prev) => ({ activeTimer: null, studySessions: [...(prev.studySessions || []), session], ...awardOnce(prev, `study-streak:${dateKey()}`, 5) }));
    showMessage('Study session saved. Break time was excluded from study duration.');
  }
  const fmt = (s) => `${String(Math.floor(s / 3600)).padStart(2, '0')}:${String(Math.floor((s % 3600) / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
  const minutes = (s) => `${Math.floor(s / 60)} min`;
  return <>
    <ModuleHead title="Study timer." description="Focus sessions are saved to your study history. Paused and break time never count as study time." />
    <div className="px-timer-layout"><section className="panel px-timer-main"><div className="panel-head"><h2>{active?.isBreak ? 'Take a breather.' : active ? 'You’re in a focus session.' : 'Ready when you are.'}</h2><span className="count-chip">{active?.status === 'running' ? (active.isBreak ? 'Break running' : 'Focus running') : active ? 'Paused' : 'No active session'}</span></div>
      {!active && <div className="px-form-grid"><Field label="Subject"><select value={subject} onChange={(e) => setSubject(e.target.value)}>{subjects.map((s) => <option>{s.name}</option>)}</select></Field><Field label="Chapter (optional)"><select value={chapter} onChange={(e) => setChapter(e.target.value)}><option value="">No specific chapter</option>{allChapters.filter((x) => x.subject === subject).map((x) => <option>{x.title}</option>)}</select></Field></div>}
      <div className={`px-clock-face ${active?.isBreak ? 'break' : ''}`}><div><strong>{fmt(totalSeconds)}</strong><span>{active?.isBreak ? 'BREAK TIME' : 'FOCUS TIME'}</span><small>{active ? `${active.subject}${active.chapter ? ` · ${active.chapter}` : ''}` : 'Choose a subject, then start studying'}</small></div></div>
      <div className="px-timer-actions">{!active ? <button className="btn btn-primary" onClick={start}>Start studying</button> : <>{active.status === 'running' ? <button className="btn btn-soft" onClick={pause}><Icon name="pause" size={17} />Pause</button> : <button className="btn btn-primary" onClick={resume}>Resume</button>}<button className="btn btn-soft" onClick={toggleBreak}>{active.isBreak ? 'Return to focus' : 'Start a break'}</button><button className="text-btn" onClick={stop}>Stop & save session</button></>}</div>
      <div className="px-timer-totals"><div><b>{fmt(focusSeconds)}</b><small>Focus duration</small></div><div><b>{fmt(breakSeconds)}</b><small>Break duration</small></div></div>
    </section><aside className="panel px-study-stats"><h2>Your study totals</h2><div className="px-stat"><b>{minutes(todayStudy)}</b><small>Today</small></div><div className="px-stat"><b>{minutes(weekStudy)}</b><small>This week</small></div><div className="px-stat"><b>{state.studySessions.length}</b><small>Saved sessions</small></div><h3>Subject-wise time</h3>{sessionsBySubject.length === 0 ? <p className="muted small">Your subject totals will appear after your first session.</p> : sessionsBySubject.map((s) => <div className="px-subject-time" key={s.name}><span>{s.icon} {s.name}</span><b>{minutes(s.seconds)}</b></div>)}</aside></div>
    <section className="panel px-history"><div className="panel-head"><h2>Session history</h2><span className="count-chip">{state.studySessions.length} sessions</span></div>{state.studySessions.length === 0 ? <p className="muted">Your completed focus sessions will appear here.</p> : [...state.studySessions].reverse().slice(0, 20).map((session) => <div className="px-history-row" key={session.id}><div><strong>{session.subject}{session.chapter ? ` · ${session.chapter}` : ''}</strong><small>{prettyDate(session.date)} · {minutes(session.breakSeconds)} break</small></div><b>{minutes(session.focusSeconds)} study</b></div>)}</section>
  </>;
}

function SettingsModule({ settings, state, onEditSettings, showMessage }) {
  async function enableNotifications() {
    if (!('Notification' in window)) return showMessage('This browser does not support notifications.');
    const result = await Notification.requestPermission();
    showMessage(result === 'granted' ? 'Browser notifications are enabled.' : 'Notification permission was not granted.');
  }
  function exportData() {
    const blob = new Blob([JSON.stringify({ settings, progress: state }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = `pathshalax-data-${dateKey()}.json`; a.click(); URL.revokeObjectURL(url);
  }
  return <>
    <ModuleHead title="Settings." description="Manage your profile, study preferences, notifications and personal data." />
    <section className="panel px-settings-card"><div className="panel-head"><div><h2>{settings.avatar} {settings.displayName || 'Student'}</h2><p className="muted small">Class {settings.classLevel} · {settings.subjects.length} subjects selected</p></div><button className="btn btn-primary" onClick={onEditSettings}>Edit profile</button></div><div className="px-settings-grid"><div><strong>Academic profile</strong><span>Board: {settings.board || 'Not set'}</span><span>Stream: {settings.stream || 'Not applicable'}</span><span>Date of birth: {settings.dateOfBirth || 'Not set'}</span></div><div><strong>Study preferences</strong><span>Daily study time: {settings.studyHours || 2} hours</span><span>Academic goal: {settings.academicGoal || 'Consistent progress'}</span><span>Difficult subjects: {(settings.difficultSubjects || []).join(', ') || 'Not set'}</span></div><div><strong>Appearance</strong><span>Theme: {settings.theme || 'Learning profile'}</span><span>Navigation: {settings.navigationPosition || 'Bottom'}</span><span>Accent: {settings.accentColor || 'Default green and gold'}</span></div></div><div className="actions-row"><button className="btn btn-soft" onClick={enableNotifications}>Enable browser notifications</button><button className="btn btn-soft" onClick={exportData}>Export my data</button></div><p className="muted small">Reminders are shown by the browser while the app is open. Closed-app and scheduled push reminders require a configured notification service.</p></section>
    <section className="panel px-privacy-card"><div className="panel-head"><h2>Weekly league history</h2><span className="count-chip">Highest: {state.highestLeague || 'Bronze'}</span></div><div className="px-settings-grid">{['Bronze', 'Silver', 'Gold', 'Diamond', 'Champion'].map((tier) => <div key={tier}><strong>{tier}</strong><b>{state.leagueAchievements?.[tier] || 0} times achieved</b></div>)}</div><div className="px-history">{(state.leagueHistory || []).length === 0 ? <p className="muted small">Your first league promotion will appear here.</p> : [...state.leagueHistory].reverse().slice(0, 8).map((entry, index) => <div className="px-history-row" key={`${entry.week}-${entry.league}-${index}`}><div><strong>{entry.league}</strong><small>Week starting {prettyDate(entry.week)}</small></div><b>{new Date(entry.achievedAt).toLocaleDateString('en-IN')}</b></div>)}</div></section>
    <section className="panel px-privacy-card"><h2>Data & privacy</h2><p>Your academic progress and personal records are stored against your signed-in student account. Archive files use a private storage bucket with account-folder access rules.</p><div className="facts"><span><b>{state.notes.length}</b> Notes</span><span><b>{state.calendarItems.length}</b> Calendar items</span><span><b>{state.archiveFiles.length}</b> Files</span><span><b>{state.studySessions.length}</b> Study sessions</span></div></section>
  </>;
}
