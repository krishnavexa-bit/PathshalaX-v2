// @ts-nocheck -- student profile fields are extended by the workspace migration.
import { useEffect, useState } from "react";
import { supabase } from '@/integrations/supabase/client';
import Icon from "./icons";
import { Backdrop, LogoMark } from "./ui";
import { CLASS_LEVELS, subjectsFor } from "./curriculum";
import type { StudentSettings } from "./cloud";

export const AVATARS = ["🦉", "🐯", "🦊", "🐼", "🐬", "🦚", "🚀", "🧪", "📐", "🌍", "🎨", "⚽"];
export const GOALS = [
  { xp: 20, label: "Easy", note: "About 10 minutes" },
  { xp: 40, label: "Steady", note: "About 20 minutes" },
  { xp: 60, label: "Serious", note: "About 30 minutes" },
  { xp: 100, label: "Champion", note: "About 45 minutes" },
];
export const THEME_CHOICES = [
  { id: "light", label: "Light" },
  { id: "dark", label: "Dark" },
  { id: "pastel", label: "Pastel" },
  { id: "colourful", label: "Colourful" },
];

export function defaultSettings(name: string): StudentSettings {
  return { displayName: name, avatar: "🦉", classLevel: 10, subjects: subjectsFor(10).map((s) => s.name), dailyGoal: 40, theme: null, dateOfBirth: null, board: 'CBSE', stream: '', studyHours: 2, academicGoal: 'Build a consistent study routine', strongSubjects: [], difficultSubjects: [], concentrationMinutes: 25, navigationPosition: 'bottom', accentColor: '#ffb703', profilePhoto: null };
}

export default function Setup({
  initial,
  mode,
  onSave,
  onCancel,
  onPreviewTheme,
  userId,
}: {
  initial: StudentSettings;
  mode: "first" | "edit";
  onSave: (s: StudentSettings) => Promise<void>;
  onCancel?: () => void;
  onPreviewTheme: (theme: string | null) => void;
  userId?: string;
}) {
  const [s, setS] = useState<StudentSettings>(initial);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [photoPreview, setPhotoPreview] = useState('');
  const subjects = subjectsFor(s.classLevel);

  useEffect(() => {
    let active = true;
    if (s.profilePhoto) supabase.storage.from('student-archive').createSignedUrl(s.profilePhoto, 60 * 60).then(({ data }) => { if (active && data?.signedUrl) setPhotoPreview(data.signedUrl); }).catch(() => {});
    return () => { active = false; };
  }, [s.profilePhoto]);

  function setClass(level: number) {
    const names = subjectsFor(level).map((x) => x.name);
    const kept = s.subjects.filter((n) => names.includes(n));
    setS({ ...s, classLevel: level, subjects: kept.length ? kept : names.slice(0, level >= 11 ? 5 : names.length), strongSubjects: (s.strongSubjects || []).filter((n) => names.includes(n)), difficultSubjects: (s.difficultSubjects || []).filter((n) => names.includes(n)), stream: level >= 11 ? (s.stream || 'Science') : '' });
  }
  function toggleSubject(name: string) {
    setS({ ...s, subjects: s.subjects.includes(name) ? s.subjects.filter((n) => n !== name) : [...s.subjects, name] });
  }
  async function uploadPhoto(file?: File) {
    if (!file) return;
    if (!userId) { setError('Sign in to upload a profile photograph.'); return; }
    if (!['image/jpeg', 'image/png', 'image/webp', 'image/gif'].includes(file.type) || file.size > 5 * 1024 * 1024) { setError('Choose a JPG, PNG, WEBP or GIF image under 5 MB.'); return; }
    setBusy(true); setError('');
    try {
      const ext = file.name.split('.').pop()?.toLowerCase() || 'jpg';
      const path = `${userId}/profile/${Date.now()}.${ext}`;
      const { error: uploadError } = await supabase.storage.from('student-archive').upload(path, file, { upsert: true, contentType: file.type });
      if (uploadError) throw uploadError;
      const { data } = await supabase.storage.from('student-archive').createSignedUrl(path, 60 * 60);
      setS((old) => ({ ...old, profilePhoto: path }));
      setPhotoPreview(data?.signedUrl || URL.createObjectURL(file));
    } catch (e) { setError(e instanceof Error ? e.message : 'Could not upload your photograph.'); }
    finally { setBusy(false); }
  }

  async function save() {
    if (!s.displayName.trim()) {
      setError("Enter your name to continue.");
      return;
    }
    if (!s.subjects.length) {
      setError("Pick at least one subject.");
      return;
    }
    if (s.dateOfBirth && s.dateOfBirth > new Date().toISOString().slice(0, 10)) {
      setError("Date of birth cannot be in the future.");
      return;
    }
    if (!Number.isFinite(Number(s.studyHours)) || s.studyHours < 0.5 || s.studyHours > 12) {
      setError("Choose between half an hour and 12 study hours per day.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      await onSave(s);
    } catch (e) {
      console.error(e);
      setError("Could not save your choices. Check your connection and try again.");
      setBusy(false);
    }
  }

  return (
    <div className="stage">
      <Backdrop />
      <main className="setup">
        <div className="card-brand"><LogoMark /><span>PathshalaX</span></div>
        <h1>{mode === "first" ? "Let’s set up your study space." : "Your profile and preferences"}</h1>
        <p className="muted">You can change any of this later from Settings.</p>

        <section className="setup-block">
          <h2>What should we call you?</h2>
          <input className="setup-input" value={s.displayName} maxLength={40} placeholder="Your first name" onChange={(e) => setS({ ...s, displayName: e.target.value })} aria-label="Your name" />
        </section>

        <section className="setup-block">
          <h2>Profile photograph (optional)</h2>
          <div className="px-profile-upload">
            <div className="avatar avatar-preview">{photoPreview ? <img src={photoPreview} alt="Profile preview" /> : s.avatar}</div>
            <label className="btn btn-soft">Upload photograph<input type="file" accept="image/*" onChange={(e) => uploadPhoto(e.target.files?.[0])} hidden /></label>
          </div>
        </section>

        <section className="setup-block">
          <h2>Pick an avatar</h2>
          <div className="avatar-grid" role="radiogroup" aria-label="Avatar">
            {AVATARS.map((a) => (
              <button key={a} type="button" role="radio" aria-checked={s.avatar === a} className={`avatar-pick ${s.avatar === a ? "on" : ""}`} onClick={() => setS({ ...s, avatar: a })}>
                {a}
              </button>
            ))}
          </div>
        </section>

        <section className="setup-block">
          <h2>Which class are you in?</h2>
          <div className="chip-row" role="radiogroup" aria-label="Class">
            {CLASS_LEVELS.map((c) => (
              <button key={c} type="button" role="radio" aria-checked={s.classLevel === c} className={`choice-chip ${s.classLevel === c ? "on" : ""}`} onClick={() => setClass(c)}>
                Class {c}
              </button>
            ))}
          </div>
        </section>

        <section className="setup-block">
          <h2>Academic details</h2>
          <div className="px-form-grid">
            <label className="px-field"><span>Date of birth (optional)</span><input type="date" value={s.dateOfBirth || ''} onChange={(e) => setS({ ...s, dateOfBirth: e.target.value || null })} /></label>
            <label className="px-field"><span>Education board</span><select value={s.board || 'CBSE'} onChange={(e) => setS({ ...s, board: e.target.value })}><option>CBSE</option><option>ICSE</option><option>ISC</option><option>State Board</option><option>Other</option></select></label>
          </div>
          {s.classLevel >= 11 && <label className="px-field"><span>Stream</span><select value={s.stream || 'Science'} onChange={(e) => setS({ ...s, stream: e.target.value })}><option>Science</option><option>Commerce</option><option>Humanities</option><option>Other</option></select></label>}
        </section>

        <section className="setup-block">
          <h2>Your subjects</h2>
          <div className="chip-row">
            {subjects.map((sub) => (
              <button key={sub.id} type="button" aria-pressed={s.subjects.includes(sub.name)} className={`choice-chip ${s.subjects.includes(sub.name) ? "on" : ""}`} onClick={() => toggleSubject(sub.name)}>
                <span aria-hidden="true">{sub.icon}</span> {sub.name}
              </button>
            ))}
          </div>
        </section>

        <section className="setup-block">
          <h2>Daily goal</h2>
          <div className="goal-grid" role="radiogroup" aria-label="Daily goal">
            {GOALS.map((g) => (
              <button key={g.xp} type="button" role="radio" aria-checked={s.dailyGoal === g.xp} className={`goal-pick ${s.dailyGoal === g.xp ? "on" : ""}`} onClick={() => setS({ ...s, dailyGoal: g.xp })}>
                <strong>{g.label}</strong>
                <span>{g.xp} XP a day</span>
                <small>{g.note}</small>
              </button>
            ))}
          </div>
          <p className="muted small">Meet your goal every day to grow your streak 🔥</p>
        </section>

        <section className="setup-block">
          <h2>Study preferences and goals</h2>
          <div className="px-form-grid">
            <label className="px-field"><span>Available study hours per day</span><select value={s.studyHours || 2} onChange={(e) => setS({ ...s, studyHours: Number(e.target.value) })}>{[1, 1.5, 2, 3, 4, 5, 6].map((x) => <option value={x}>{x} hours</option>)}</select></label>
            <label className="px-field"><span>Concentration block</span><select value={s.concentrationMinutes || 25} onChange={(e) => setS({ ...s, concentrationMinutes: Number(e.target.value) })}>{[15, 25, 35, 45, 60].map((x) => <option value={x}>{x} minutes</option>)}</select></label>
          </div>
          <label className="px-field"><span>Academic goal</span><input maxLength={120} value={s.academicGoal || ''} onChange={(e) => setS({ ...s, academicGoal: e.target.value })} placeholder="e.g. Improve my Maths score" /></label>
          <h3>Subjects you feel confident in</h3>
          <div className="chip-row">{subjects.map((sub) => <button key={`strong-${sub.id}`} type="button" aria-pressed={(s.strongSubjects || []).includes(sub.name)} className={`choice-chip ${(s.strongSubjects || []).includes(sub.name) ? 'on' : ''}`} onClick={() => setS({ ...s, strongSubjects: (s.strongSubjects || []).includes(sub.name) ? s.strongSubjects.filter((x) => x !== sub.name) : [...(s.strongSubjects || []), sub.name] })}>{sub.name}</button>)}</div>
          <h3>Subjects you find difficult</h3>
          <div className="chip-row">{subjects.map((sub) => <button key={`difficult-${sub.id}`} type="button" aria-pressed={(s.difficultSubjects || []).includes(sub.name)} className={`choice-chip ${(s.difficultSubjects || []).includes(sub.name) ? 'on' : ''}`} onClick={() => setS({ ...s, difficultSubjects: (s.difficultSubjects || []).includes(sub.name) ? s.difficultSubjects.filter((x) => x !== sub.name) : [...(s.difficultSubjects || []), sub.name] })}>{sub.name}</button>)}</div>
          <div className="px-form-grid">
            <label className="px-field"><span>Navigation position</span><select value={s.navigationPosition || 'bottom'} onChange={(e) => setS({ ...s, navigationPosition: e.target.value })}><option value="bottom">Bottom</option><option value="top">Top</option></select></label>
            <label className="px-field"><span>Accent colour</span><select value={s.accentColor || '#ffb703'} onChange={(e) => setS({ ...s, accentColor: e.target.value })}><option value="#ffb703">Sunshine gold</option><option value="#14a07a">Mint green</option><option value="#ff6b4a">Coral</option><option value="#71bdf2">Sky blue</option></select></label>
          </div>
        </section>

        <section className="setup-block">
          <h2>Colour theme</h2>
          <div className="chip-row" role="radiogroup" aria-label="Colour theme">
            <button type="button" role="radio" aria-checked={s.theme === null} className={`choice-chip ${s.theme === null ? "on" : ""}`} onClick={() => { setS({ ...s, theme: null }); onPreviewTheme(null); }}>
              Match my learning profile
            </button>
            {THEME_CHOICES.map((t) => (
              <button key={t.id} type="button" role="radio" aria-checked={s.theme === t.id} className={`choice-chip theme-chip theme-${t.id} ${s.theme === t.id ? "on" : ""}`} onClick={() => { setS({ ...s, theme: t.id }); onPreviewTheme(t.id); }}>
                {t.label}
              </button>
            ))}
          </div>
        </section>

        {error && <div className="auth-error" role="alert">{error}</div>}
        <div className="actions-row">
          <button type="button" className="btn btn-primary magnetic" onClick={save} disabled={busy}>
            {busy ? "Saving…" : mode === "first" ? "Start learning" : "Save changes"}
            <Icon name="arrow" size={18} className="arr" />
          </button>
          {onCancel && <button type="button" className="text-btn" onClick={onCancel}>Cancel</button>}
        </div>
      </main>
    </div>
  );
}
