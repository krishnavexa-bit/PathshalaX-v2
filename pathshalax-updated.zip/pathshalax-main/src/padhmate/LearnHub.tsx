import { useState } from "react";
import Icon from "./icons";
import { ncertLink, subjectsFor, findChapter, type Chapter } from "./curriculum";
import { GAMES, relatedGame, type GameId } from "./games/catalog";
import type { StudentSettings } from "./cloud";

type Props = {
  settings: StudentSettings;
  completed: string[];
  subjectName: string | null;
  chapterId: string | null;
  onOpen: (subjectName: string | null, chapterId: string | null) => void;
  onComplete: (chapterId: string, event: React.MouseEvent) => void;
  onOpenSample: () => void;
  onOpenGame: (id: GameId) => void;
};

export default function LearnHub(props: Props) {
  const { settings, completed, subjectName, chapterId, onOpen } = props;
  const all = subjectsFor(settings.classLevel);
  const mine = all.filter((s) => settings.subjects.includes(s.name));
  const list = mine.length ? mine : all;
  const subject = list.find((s) => s.name === subjectName) ?? list[0];

  if (chapterId) {
    const found = findChapter(chapterId);
    if (found) return <ChapterView {...props} chapter={found.chapter} subject={found.subject.name} classLevel={found.classLevel} />;
  }

  return (
    <>
      <header className="page-head">
        <div>
          <h1>Learn at your pace.</h1>
          <p>Class {settings.classLevel} · organised NCERT chapters, original study activities and progress tracking.</p>
        </div>
      </header>
      <div className="subject-tabs" role="tablist" aria-label="Subjects">
        {list.map((s) => {
          const done = s.chapters.filter((c) => completed.includes(c.id)).length;
          return (
            <button key={s.id} type="button" role="tab" aria-selected={subject?.id === s.id} className={`subject-tab rip ${subject?.id === s.id ? "on" : ""}`} onClick={() => onOpen(s.name, null)}>
              <span className="subject-icon" aria-hidden="true">{s.icon}</span>
              <span><strong>{s.name}</strong><small>{done}/{s.chapters.length} done</small></span>
            </button>
          );
        })}
      </div>
      {subject && (
        <section className="panel chapters-panel">
          <div className="panel-head">
            <h2>{subject.icon} {subject.name}</h2>
            <span className="count-chip">{subject.books.map((b) => b.title).join(" · ")}</span>
          </div>
          <div className="bar"><span style={{ width: `${Math.round((subject.chapters.filter((c) => completed.includes(c.id)).length / subject.chapters.length) * 100)}%` }} /></div>
          <div className="chapter-grid">
            {subject.chapters.map((c, i) => {
              const done = completed.includes(c.id);
              const sample = settings.classLevel === 10 && subject.name === "Mathematics" && /quadratic/i.test(c.title);
              const game = relatedGame(subject.name, c.title);
              return (
                <button key={c.id} type="button" className={`chapter-card tilt rip ${done ? "is-done" : ""}`} style={{ "--i": i } as React.CSSProperties} onClick={() => onOpen(subject.name, c.id)}>
                  <span className="node">{done ? <Icon name="check" size={16} strokeWidth={3} /> : i + 1}</span>
                  <span className="chapter-text"><strong>{c.title}</strong><small>{c.book}</small></span>
                  <span className="chapter-tags">{sample && <span className="tag good">Interactive</span>}{game && <span className="tag game-tag" title="Has a matching activity">🎮</span>}</span>
                </button>
              );
            })}
          </div>
        </section>
      )}
    </>
  );
}

function ChapterView(props: Props & { chapter: Chapter; subject: string; classLevel: number }) {
  const { chapter, subject, classLevel, completed, onOpen, onComplete, onOpenSample, onOpenGame } = props;
  const [checklist, setChecklist] = useState([false, false, false]);
  const done = completed.includes(chapter.id);
  const sample = classLevel === 10 && subject === "Mathematics" && /quadratic/i.test(chapter.title);
  const game = relatedGame(subject, chapter.title);
  const gameInfo = GAMES.find((g) => g.id === game);
  const resource = subject === 'Mathematics'
    ? ['Understand the key definition and notation.', 'Work through at least two textbook examples.', 'Solve the exercise questions without looking at the solution.']
    : subject === 'Science' || subject === 'Physics' || subject === 'Chemistry' || subject === 'Biology'
      ? ['Identify the central scientific idea and vocabulary.', 'Draw or label a diagram from memory.', 'Explain one real-world example in your own words.']
      : ['Build a short timeline, map or concept outline.', 'Write down important names, dates or terms.', 'Summarise the chapter in five points.'];

  return (
    <>
      <div className="chapter-crumbs"><button type="button" className="text-btn" onClick={() => onOpen(subject, null)}><Icon name="arrow" size={16} className="flip" /> {subject} chapters</button></div>
      <article className="notebook chapter-notebook">
        <div className="notebook-top"><span className="lesson-badge">Class {classLevel} · {subject} · {chapter.book}</span><a className="text-btn" href={ncertLink(chapter)} target="_blank" rel="noreferrer">Official NCERT chapter ↗</a></div>
        <h2>{chapter.title}</h2>
        <p className="lead">Use this chapter space to study the official textbook, practise an associated activity and record your progress. Chapter content is manually curated; this version does not generate notes or questions.</p>
        {(sample || gameInfo) && <div className="chapter-extras">
          {sample && <button type="button" className="extra-card rip" onClick={onOpenSample}><span aria-hidden="true">✍️</span><span><strong>Interactive quadratic lessons</strong><small>Five authored lessons with worked examples and checkpoints</small></span></button>}
          {gameInfo && <button type="button" className="extra-card rip" onClick={() => onOpenGame(gameInfo.id)}><span aria-hidden="true">{gameInfo.icon}</span><span><strong>Play: {gameInfo.title}</strong><small>{gameInfo.text}</small></span></button>}
        </div>}
        <section className="px-chapter-study"><h3 className="sub">A simple study checklist</h3><p className="muted">Tick these steps as you work through the official chapter.</p>{resource.map((item, i) => <label className="px-checklist-row" key={item}><input type="checkbox" checked={checklist[i]} onChange={(e) => setChecklist((old) => old.map((v, index) => index === i ? e.target.checked : v))} /><span>{item}</span></label>)}</section>
        <div className="sticky checkpoint"><Icon name="target" size={22} /><div><strong>Learning reflection</strong><p>Before completing the chapter, explain its main idea aloud, list the parts you still find difficult and add any questions to Doubts & Review.</p></div></div>
        <div className="notebook-actions"><button type="button" className={`btn magnetic ${done ? "btn-complete" : "btn-primary"}`} disabled={done} onClick={(e) => onComplete(chapter.id, e)}>{done ? <><Icon name="check" size={18} strokeWidth={3} />Chapter completed</> : "Mark chapter complete (+50 XP)"}</button><a className="text-btn" href={`https://www.khanacademy.org/search?page_search_query=${encodeURIComponent(chapter.title)}`} target="_blank" rel="noreferrer">Find free video lessons ↗</a></div>
      </article>
    </>
  );
}
