# PathshalaX database and service setup

PathshalaX keeps the existing Supabase project and its existing `user_progress`, `learning_profiles`, and `student_settings` tables. The current application stores connected academic records in the signed-in student's `user_progress.progress` JSONB document, while profile and onboarding preferences remain in `student_settings`. The existing row-level security policies scope these rows to `auth.uid()`.

## Apply the workspace migration

In the Supabase dashboard for the project already used by this repository:

1. Open **SQL Editor**.
2. Run the existing migrations, in order, only if they have not already been applied:
   - `drizzle/migrations/0000_padhmate_progress_and_profiles.sql`
   - `drizzle/migrations/0001_pathshalax_settings_and_lessons.sql`
3. Run `drizzle/migrations/0002_pathshalax_workspace.sql`.
4. Confirm that the `student-archive` bucket exists and is **private**. The migration sets a 20 MB per-file limit and adds storage object policies that require the first storage path segment to equal the authenticated user's UUID.

The `chapter_lessons` table from migration 0001 is a legacy schema object. The current application no longer reads or writes it and does not call any AI service.

## Authentication

In Supabase **Authentication → Providers**:

- Enable Email authentication. Configure email confirmation and SMTP delivery as appropriate for production.
- Enable Google and enter the Google OAuth client ID and secret.
- Add the deployed application URL and local development URL to the allowed redirect URLs (for example `http://localhost:3000/**` and your production domain).
- Enable anonymous sign-ins only if Guest mode is desired.

The website implements email/password sign-in, sign-up, password reset and recovery, Google OAuth through the existing Lovable auth adapter, and anonymous guest sessions. Provider credentials and email delivery are external Supabase configuration; they are not included in this source archive.

## Environment variables

Use the existing environment variable names. Create a local `.env` file or set equivalent values in your hosting provider:

```dotenv
VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_PUBLISHABLE_KEY
SUPABASE_URL=https://YOUR_PROJECT.supabase.co
SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_PUBLISHABLE_KEY
```

Never place a Supabase service-role key in browser-exposed variables. The current browser-side archive uses the authenticated Supabase client and RLS/storage policies; it does not need a service-role key.

## Data model

- `student_settings`: student identity/profile, class, board, stream, subjects, date of birth, preferences and private profile-photo storage path.
- `user_progress.progress`: existing lesson/question progress plus calendar items, tracker questions, doubt notes, notes/flashcards/formulas, study sessions, active timer state, archive metadata, test results and reward ledger. All are stored in the same student-owned row to avoid parallel copies of academic records.
- `learning_profiles`: the pre-existing optional learning-preference survey.
- `student-archive` storage bucket: private file bytes for notes, documents, presentations, images and profile photos. Paths begin with the authenticated student's UUID.

The archive metadata is stored in the student's progress document; the actual file bytes live in Supabase Storage. Keep both the `user_progress` table policies and the storage object policies enabled.

## Important content dependency

The existing project supplies the NCERT chapter catalogue and a small authored Class 10 Mathematics — Quadratic Equations question/lesson set. The new test centre uses this managed question bank and deliberately does not generate questions. To enable full Class 6–12 chapter-wise notes, videos, activities and tests, add reviewed, licensed educational content and questions to the repository's curriculum/question data. A complete publisher-quality content bank is not included in the uploaded project, and this implementation does not fabricate one.
