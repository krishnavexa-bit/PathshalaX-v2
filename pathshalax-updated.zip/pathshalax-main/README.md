# PathshalaX

PathshalaX is a student learning and academic management application for Classes 6–12. This implementation extends the supplied React/TanStack Start + Supabase project and preserves its established PathshalaX visual identity and responsive interface.

## Local development

Requirements: Node.js 20+ and npm.

```sh
npm install
npm run dev
```

Production build and checks:

```sh
npm run build
npm test
npm run lint
```

## Backend configuration

This project continues to use its existing Supabase project. Follow [DATABASE.md](./DATABASE.md) for migrations, authentication providers, private archive storage policies, and environment configuration. Do not expose a service-role key in a `VITE_` variable.

## Implemented modules

- Email/password sign-in, registration, password reset/recovery, Google OAuth, and guest sessions.
- Student onboarding/profile settings: DOB, optional photo, class, board, stream, subjects, study hours/goals, strong/difficult subjects, focus interval, theme, accent and navigation position.
- Dashboard with saved study targets, chapter completion, question accuracy, tasks, exams, focus time, points and league.
- Calendar/task manager with events, homework, exams, priorities, recurrence and in-app browser notifications while the site is open.
- Rule-based editable seven-day study planner.
- Topic-level question tracker accepting individual numbers and ranges; incorrect and unattempted records are reflected in Doubts & Review.
- Doubts & Review with student notes, personal explanations and resolved/reopen status.
- Learn catalogue backed by the existing NCERT chapter list, existing authored Class 10 Quadratics lessons, and relevant existing learning games.
- Private Personal Archive with upload, download, preview for images/PDF, search, folders/subfolders, rename, move and delete.
- Tests & Examination Centre using the repository's managed question bank, timer, question map, answer selection, mark-for-review, results and mistake sync.
- Notes & Smart Revision for notes, manual flashcards, formulas, definitions and revision sheets.
- Persistent focus timer with pause/resume, breaks and subject/chapter history; break time is excluded from study totals.
- Settings, data export, browser-notification permission, account logout and shared rewards/weekly-league records.

## Scope and content notes

The supplied project contains a Class 6–12 NCERT chapter catalogue, but only a limited authored lesson/question bank (Class 10 Mathematics — Quadratic Equations). The learning interface uses official NCERT links and existing authored activities where available; the test centre clearly identifies the current bank. Full textbook explanations, curated questions, lecture videos, and every requested subject-specific simulator require reviewed/licensed content assets that were not present in the uploaded project. No AI integration or AI-generated content is used in this version.

Push notifications while the browser/app is closed require a separately configured push/notification service. Current reminders use the browser Notification API while the website is open and permission has been granted.
